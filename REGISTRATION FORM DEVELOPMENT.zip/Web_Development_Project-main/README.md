# Master_Trail

JavaScript Form Validation

Many websites utilize form validation for client-side validation of user details, card details, address details, and other information. If a mandatory input field 
name exists, the user can type a number, leave the field blank, type only one letter, and so on. All of these validations are simple to implement using JavaScript.
Implement thefollowing validations.
